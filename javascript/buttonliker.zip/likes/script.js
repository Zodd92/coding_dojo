var like=0;
var countEle= document.querySelector("#like");

function addLike(){
     like++;
     countEle.innerText=like + "like(s)"
}